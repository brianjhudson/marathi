module.exports = {
  secret: "SCdvasdkjjgaqewervasdfdf000123fvasd..raer"
}
