module.exports = {
  clientId: "1662491554080435"
  , secret: "fddad5818de5ba558434f19845ab828c"
  , cbUrl: "http://localhost:3000/auth/facebook/callback"
};
