module.exports = {
  mongoUri: "mongodb://bjhudson:Mhanto.4717@ds053166.mlab.com:53166/language-app"
};
